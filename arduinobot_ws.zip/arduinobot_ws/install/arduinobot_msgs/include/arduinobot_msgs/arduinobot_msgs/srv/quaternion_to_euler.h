// generated from rosidl_generator_c/resource/idl.h.em
// with input from arduinobot_msgs:srv/QuaternionToEuler.idl
// generated code does not contain a copyright notice

#ifndef ARDUINOBOT_MSGS__SRV__QUATERNION_TO_EULER_H_
#define ARDUINOBOT_MSGS__SRV__QUATERNION_TO_EULER_H_

#include "arduinobot_msgs/srv/detail/quaternion_to_euler__struct.h"
#include "arduinobot_msgs/srv/detail/quaternion_to_euler__functions.h"
#include "arduinobot_msgs/srv/detail/quaternion_to_euler__type_support.h"

#endif  // ARDUINOBOT_MSGS__SRV__QUATERNION_TO_EULER_H_
