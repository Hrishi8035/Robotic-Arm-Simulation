// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ARDUINOBOT_MSGS__SRV__QUATERNION_TO_EULER_HPP_
#define ARDUINOBOT_MSGS__SRV__QUATERNION_TO_EULER_HPP_

#include "arduinobot_msgs/srv/detail/quaternion_to_euler__struct.hpp"
#include "arduinobot_msgs/srv/detail/quaternion_to_euler__builder.hpp"
#include "arduinobot_msgs/srv/detail/quaternion_to_euler__traits.hpp"

#endif  // ARDUINOBOT_MSGS__SRV__QUATERNION_TO_EULER_HPP_
