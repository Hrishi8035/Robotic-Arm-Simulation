// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ARDUINOBOT_MSGS__SRV__ADD_TWO_INTS_HPP_
#define ARDUINOBOT_MSGS__SRV__ADD_TWO_INTS_HPP_

#include "arduinobot_msgs/srv/detail/add_two_ints__struct.hpp"
#include "arduinobot_msgs/srv/detail/add_two_ints__builder.hpp"
#include "arduinobot_msgs/srv/detail/add_two_ints__traits.hpp"

#endif  // ARDUINOBOT_MSGS__SRV__ADD_TWO_INTS_HPP_
