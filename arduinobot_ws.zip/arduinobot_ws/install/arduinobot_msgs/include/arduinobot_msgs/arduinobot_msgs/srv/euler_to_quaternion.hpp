// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ARDUINOBOT_MSGS__SRV__EULER_TO_QUATERNION_HPP_
#define ARDUINOBOT_MSGS__SRV__EULER_TO_QUATERNION_HPP_

#include "arduinobot_msgs/srv/detail/euler_to_quaternion__struct.hpp"
#include "arduinobot_msgs/srv/detail/euler_to_quaternion__builder.hpp"
#include "arduinobot_msgs/srv/detail/euler_to_quaternion__traits.hpp"

#endif  // ARDUINOBOT_MSGS__SRV__EULER_TO_QUATERNION_HPP_
