// generated from rosidl_generator_c/resource/idl.h.em
// with input from arduinobot_msgs:srv/EulerToQuaternion.idl
// generated code does not contain a copyright notice

#ifndef ARDUINOBOT_MSGS__SRV__EULER_TO_QUATERNION_H_
#define ARDUINOBOT_MSGS__SRV__EULER_TO_QUATERNION_H_

#include "arduinobot_msgs/srv/detail/euler_to_quaternion__struct.h"
#include "arduinobot_msgs/srv/detail/euler_to_quaternion__functions.h"
#include "arduinobot_msgs/srv/detail/euler_to_quaternion__type_support.h"

#endif  // ARDUINOBOT_MSGS__SRV__EULER_TO_QUATERNION_H_
