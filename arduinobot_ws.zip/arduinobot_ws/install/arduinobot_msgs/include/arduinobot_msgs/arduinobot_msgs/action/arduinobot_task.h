// generated from rosidl_generator_c/resource/idl.h.em
// with input from arduinobot_msgs:action/ArduinobotTask.idl
// generated code does not contain a copyright notice

#ifndef ARDUINOBOT_MSGS__ACTION__ARDUINOBOT_TASK_H_
#define ARDUINOBOT_MSGS__ACTION__ARDUINOBOT_TASK_H_

#include "arduinobot_msgs/action/detail/arduinobot_task__struct.h"
#include "arduinobot_msgs/action/detail/arduinobot_task__functions.h"
#include "arduinobot_msgs/action/detail/arduinobot_task__type_support.h"

#endif  // ARDUINOBOT_MSGS__ACTION__ARDUINOBOT_TASK_H_
