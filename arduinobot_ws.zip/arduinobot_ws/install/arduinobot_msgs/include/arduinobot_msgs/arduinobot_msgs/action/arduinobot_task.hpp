// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ARDUINOBOT_MSGS__ACTION__ARDUINOBOT_TASK_HPP_
#define ARDUINOBOT_MSGS__ACTION__ARDUINOBOT_TASK_HPP_

#include "arduinobot_msgs/action/detail/arduinobot_task__struct.hpp"
#include "arduinobot_msgs/action/detail/arduinobot_task__builder.hpp"
#include "arduinobot_msgs/action/detail/arduinobot_task__traits.hpp"

#endif  // ARDUINOBOT_MSGS__ACTION__ARDUINOBOT_TASK_HPP_
